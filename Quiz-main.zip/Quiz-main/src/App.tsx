import React from 'react';
import Quiz from './components/Quiz';

function App() {
  return <Quiz />;
}

export default App;